
var liElements = document.querySelectorAll("li")
const firstUl = document.querySelector(".firstUl"),
    secondUl = document.querySelector(".secondUl");

function Move(sender) {



    if (firstUl.contains(sender)) {
        const node = document.createElement("li");
        node.innerHTML = sender.textContent;
        node.addEventListener('dblclick', function(sender){Move(sender.target)});
        node.addEventListener("mouseover", egerravisz(node))
        node.addEventListener("mouseout", egerlevesz(node))
        secondUl.appendChild(node);
        sender.remove(); 
        
    }
    else if (secondUl.contains(sender)) {
        const node = document.createElement("li");
        node.innerHTML = sender.textContent;
        node.addEventListener('dblclick', function(sender){Move(sender.target)});
        node.addEventListener("mouseover", egerravisz(node))
        node.addEventListener("mouseout", egerlevesz(node))
        firstUl.appendChild(node);
        sender.remove(); 
    }

    
}

 function egerravisz(valami ) {
    valami.style.color = "black"
    valami.style.listStyleImage = "url('tick.png')";
    valami.style.color = "red"

 }

 
 function egerlevesz() {

    valami.style.color = "red"
    valami.style.listStyleImage = "url('unchecked.png')";
    valami.style.color = "black";
 }

document.querySelectorAll(".firstUl li, .secondUl li").forEach(item => {
    item.addEventListener('dblclick', function(event){Move(event.target)});
    item.addEventListener("mouseover", egerravisz(node))
    item.addEventListener("mouseout", egerlevesz(node))
});
    
